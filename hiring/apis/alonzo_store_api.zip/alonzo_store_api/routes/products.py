from fastapi import APIRouter, HTTPException
from models import Product, ProductCreate
from storage import products, save_products, get_next_id

router = APIRouter()

@router.get("/")
def list_products():
    return products

@router.post("/")
def create_product(data: ProductCreate):
    new_id = get_next_id(products)
    product = Product(id=new_id, **data.dict())
    products.append(product.dict())
    save_products()
    return product

@router.put("/{product_id}")
def update_product(product_id: int, data: ProductCreate):
    for i, p in enumerate(products):
        if p["id"] == product_id:
            updated = Product(id=product_id, **data.dict())
            products[i] = updated.dict()
            save_products()
            return updated
    raise HTTPException(status_code=404, detail="Product not found")

@router.delete("/{product_id}")
def delete_product(product_id: int):
    for i, p in enumerate(products):
        if p["id"] == product_id:
            products.pop(i)
            save_products()
            return {"message": "Deleted"}
    raise HTTPException(status_code=404, detail="Product not found")