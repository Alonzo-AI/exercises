# Alonzo Store Admin API (Mock)

Run with:
```bash
uvicorn main:app --reload
```